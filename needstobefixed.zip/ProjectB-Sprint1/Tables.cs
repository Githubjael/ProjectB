public class Tables
{
    public int ID;
    // public List<int> IDs = new List<int>();
    public string Type;
    public bool Reserved;
    public int GuestID;
    // public int Amount;
    public Tables(int id, string type)
    {
        ID = id;
        Type = type;
        Reserved = false;
        // Amount = amount;
    }
    // public Tables(List<int> ID)
    // {
    //     IDs = ID;
    // }
}