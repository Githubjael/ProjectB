public static class DisplayTables
{
    public static void Border()
    {
        string draw;
        draw = @"|---------------------------------------------------------|
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|                                                         |
|---------------------------------------------------------|";
        Console.WriteLine(draw);
    }
}