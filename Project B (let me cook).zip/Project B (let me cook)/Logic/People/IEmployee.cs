public interface IEmployee{
    string EmployeeCode {get;}
}